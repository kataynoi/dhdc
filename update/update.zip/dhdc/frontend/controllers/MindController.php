<?php

namespace frontend\controllers;

class MindController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
