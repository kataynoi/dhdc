<?php

namespace frontend\controllers;

class CdController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
