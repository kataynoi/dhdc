<?php

namespace frontend\controllers;

use \backend\models\Sysconfigmain;

class SummaryController extends \yii\web\Controller {

    public function actionIndex() {
       
    }
    
    

}
