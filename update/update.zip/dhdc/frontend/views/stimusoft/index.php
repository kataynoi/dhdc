<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\CustomReportSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Custom Reports (Stimusoft)';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="custom-report-index">

    
    <div class="alert alert-danger">
        
        <h1>ท่านสามารถใช้งาน Custom Report ได้ โดยการติดตั้งระบบ DHDC Custom Report</h1>
        
    </div>

    
    
</div>
